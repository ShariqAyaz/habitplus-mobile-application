module.exports = {
    project: {
      ios: {},
      android: {},
    },
    assets: ['./assets/fonts'],
  };
import { database } from './index'; // Adjust the path according to your project structure

async function seedDatabase() {
  const hasData = await database.collections.get('apps').query().fetchCount();
  if (hasData === 0) {
    console.log("\n\nNO DATA found\n\n");
    return;
    // Assuming you want to seed the `apps` table as an example
    await database.action(async () => {
      const appsCollection = database.collections.get('apps');
      await appsCollection.create((app) => {
        app.title = 'Initial App';
        app.description = 'This is the first app seeded into the database.';
        app.created_at = Date.now();
        app.updated_at = Date.now();
        app.author = 'Admin';
      });

      // Add more seeding logic here for other tables as necessary
    });
  }
}

export default seedDatabase;
